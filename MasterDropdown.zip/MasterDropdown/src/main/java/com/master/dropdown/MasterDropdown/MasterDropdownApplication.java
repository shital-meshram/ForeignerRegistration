package com.master.dropdown.MasterDropdown;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MasterDropdownApplication {

	public static void main(String[] args) {
		SpringApplication.run(MasterDropdownApplication.class, args);
	}

}
