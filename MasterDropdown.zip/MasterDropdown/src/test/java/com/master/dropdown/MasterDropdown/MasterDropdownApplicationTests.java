package com.master.dropdown.MasterDropdown;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MasterDropdownApplicationTests {

	@Test
	void contextLoads() {
	}

}
