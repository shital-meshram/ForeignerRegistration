package com.example.ForeignerRegistration;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ForeignerRegistrationApplicationTests {

	@Test
	void contextLoads() {
	}

}
