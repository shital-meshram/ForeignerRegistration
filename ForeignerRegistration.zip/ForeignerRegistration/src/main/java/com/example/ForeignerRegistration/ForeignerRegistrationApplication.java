package com.example.ForeignerRegistration;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ForeignerRegistrationApplication {

	public static void main(String[] args) {
		SpringApplication.run(ForeignerRegistrationApplication.class, args);
	}

}
